#!/bin/bash
NODE_MODULES=/workspace/node_modules && cd /workspace

# Check if modules are present
if [ -z "$(ls -A ${NODE_MODULES})" ]; then
    npm i
fi

# Start the main process in background & remember the pid
rm /workspace/.nuxt/ -rf
./node_modules/.bin/nodemon --legacy-watch --watch pages --watch components --exec ./node_modules/.bin/nuxt&
MAIN_PROCESS_PID=$!

echo -n $MAIN_PROCESS_PID > /tmp/pid.tmp
while sleep 1000; do :; done