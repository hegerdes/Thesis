#!/bin/bash

PID_FILE=/tmp/pid.tmp

if test -f "$PID_FILE"; then
    echo "Killing main process (PID: $(cat $PID_FILE))"
    kill "$(cat $PID_FILE)"
    rm $PID_FILE
fi
