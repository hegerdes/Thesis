# Thesis Example Project ReadMe

Die Dateien in diesem Verzeichnis stellen eine Beispielhafte Umsetzung des in der Arbeit beschriebenen Konzepts da!

Das bei Symbic implementierte Projekt kann aufgrund von Vertraulichkeitsbestimmungen nicht zur Verfügung gestellt werden. Aus diesem Grund habe ich dieses kleine Projekt extra nachgebaut.

---

![alt text](./0-mgmt/config/pic.png)

## How To Use

Um das Projekt auf dem Rechner Auszuführen sind keine Programme außer Docker (Desktop) nötig.
Alle benötigten Programme, Runtimes und Co werden automatisch heruntergeladen oder durch ein gebautes image bereitgestellt.

Nutzen der Programme:
```bash
#!/bin/bash
cd ExampleProject
docker-compose --version    #Check version
docker-compose up           #Start all apps
```

Die einzelnen Programme haben nicht sonderlich viel Funktionen und dienen nur der Demonstration. Dennoch können die Funktionen einiger Anwendungen mit der bereitgestellten Postamn Collection getestet werden.


## Backgrund

Im Verzeichnis 0-mgmt sind Anwendungsübergreifende Skripte und Settings gespeichert. Alle darin befindlichen Skripte werden aktiv genutzt um den Entwickungsaufwand zu verringern. Leider kann das volle Potential dieser Skripte nur genutzt werden wenn eine GitLab Instanz bereitsteht. Diese wurde aber aufgrund der Projektvertraulichkeit aus den Skripten entfernt.
