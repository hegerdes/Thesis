#!/bin/bash

cd /workspace
pip3 install -r requirements.txt

# DB Status/Update check
cd db
python3 worker.py&
cd ..

# Start the main process in background & remember the pid
python3 app.py&
MAIN_PROCESS_PID=$!

echo -n $MAIN_PROCESS_PID > /tmp/pid.tmp
while sleep 1000; do :; done