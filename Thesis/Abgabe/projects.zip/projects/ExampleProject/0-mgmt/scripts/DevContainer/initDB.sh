#!/bin/bash

# Change cwd
cd "$(dirname "$0")"
cd ../..


USE_SUDO=""
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    USE_SUDO="sudo "
fi

$USE_SUDO docker-compose -f docker-compose.yml up -d db

# Init and fill db
echo "Creating DB Schemas"

$USE_SUDO docker-compose -f docker-compose.yml stop
