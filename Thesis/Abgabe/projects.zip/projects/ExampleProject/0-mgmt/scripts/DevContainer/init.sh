#!/bin/bash

# Change cwd
cd "$(dirname "$0")"
bash gitCloneAll.sh
bash createComposeSymlink.sh
bash pullDevImages.sh
bash initDB.sh
