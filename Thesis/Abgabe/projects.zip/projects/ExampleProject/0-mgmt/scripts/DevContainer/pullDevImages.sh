#!/bin/bash

CONTAINER_REGESTRY="YOUR URL"
# Change cwd
cd "$(dirname "$0")"
# Go up a level
cd ..

USE_SUDO=""
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    USE_SUDO="sudo "
fi

# Log into ContainerRegistry
echo "Logging into Container Regestry docker login YOUR URL ..."
$USE_SUDO docker login YOUR URL

# Add your repo here
# Path must be relative to this script
$USE_SUDO docker pull YOUR URL/node-dev-container
$USE_SUDO docker pull YOUR URL/php-dev-container

# Go to root dir and recreate container
cd ..
$USE_SUDO docker-compose \
    -f docker-compose.yml \
    up --no-start