#!/bin/bash



if [ "$#" -ne 1 ]; then
    echo "Illegal number of parameters"
    echo "Specify the dir od SQL dump files"
    exit
fi

SQL_DUMP_DIR=$(realpath $1)
# Change cwd
cd "$(dirname "$0")"
# Go up a level
cd ../..

for filename in $SQL_DUMP_DIR/*.sql; do
    echo "Adding ${filename}..."
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux compose support
        docker-compose exec -T db sh -c "exec mysql -uroot -pyes" < ${filename}
    else
        # Win/MacOS
        docker compose exec -T db sh -c "exec mysql -uroot -pyes" < ${filename}
    fi
done