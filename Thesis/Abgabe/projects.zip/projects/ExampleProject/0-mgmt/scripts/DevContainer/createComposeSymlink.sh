#!/bin/bash


# Change cwd
cd "$(dirname "$0")"

FILES=(docker-compose.yml)
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    echo Found Linux
    for FILE in ${FILES[@]}; do
        if [ ! -f ../../$FILE ]; then
            ln ../$FILE ../../$FILE
        fi
    done
elif [[ "$OSTYPE" == "darwin"* ]]; then
    # Mac OSX
    echo Found MacOS
    echo Not supprted yet
    exit 1
elif [[ "$OSTYPE" == "cygwin" ]]; then
    # POSIX compatibility layer and Linux environment emulation for Windows
    echo Found Windows
    ./createComposeSymlink.bat
elif [[ "$OSTYPE" == "msys" ]]; then
    # Lightweight shell and GNU utilities compiled for Windows (part of MinGW)
    echo Found Windows
    ./createComposeSymlink.bat
elif [[ "$OSTYPE" == "win32" ]]; then
    # Windows.
    echo Found Windows
    ./createComposeSymlink.bat
else
    # Unknown.
    echo Error. No supported OS
    exit 1
fi

echo All done