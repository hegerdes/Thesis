#!/bin/bash

# Change cwd
cd "$(dirname "$0")"
# Go up a level
cd ../..

# Add your repo here
# Path must be relative to this script
REPOS="$(tail -n 1 repos.txt)"
cd ..
for REPO in ${REPOS[@]}; do
    echo "Your URL here"
done