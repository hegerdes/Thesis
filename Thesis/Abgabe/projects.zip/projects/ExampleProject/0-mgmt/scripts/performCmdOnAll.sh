#!/bin/bash

# Change cwd
cd "$(dirname "$0")"
# Go up a level
cd ..

# Add your repo here
# Path must be relative to this script
REPOS="$(tail -n 1 repos.txt)"
FAILS=()

# Go up a level
cd ..
MY_PATH=$(pwd)

echo "Running "$@" on all repos"
for REPO in ${REPOS[@]}; do
    echo "Entering and performing task \"${@:1}\" on ${REPO}"
    cd $REPO
    bash -c "${*:1}"
    if [ $? -eq 0 ]; then
        echo "Done"
    else
        FAILS+=($REPO)
        echo "Command faild"
    fi
    cd $MY_PATH
done

if [ ${#FAILS[@]} -eq 0 ]; then
    echo "All commands sucseeded"
else
    echo "The following repos exited with an error: ${FAILS}"
fi
