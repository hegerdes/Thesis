#!/bin/bash

NODE_MODULES=/workspace/node_modules
cd /workspace

# Check if modules are present
if [ -z "$(ls -A ${NODE_MODULES})" ]; then
   npm config set user 0
   npm i
fi

# start the main process in background
# Remember the PID and run sleep to to keep container running
./node_modules/.bin/nodemon --legacy-watch --trace-warnings --trace-uncaught ./bin/www &
MAIN_PROCESS_PID=$!


echo -n $MAIN_PROCESS_PID > /tmp/pid.tmp
echo "Saved process ID ${MAIN_PROCESS_PID} to /tmp/pid.tmp"
while sleep 1000; do :; done
