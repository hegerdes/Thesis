#!/bin/bash

# Called when you open devcontainer in vscode
# Give user controll over process

PID_FILE=/tmp/pid.tmp
NODE_MODULES=/workspace/node_modules
if test -f "$PID_FILE"; then
    echo "Killing main process (PID: "$(cat $PID_FILE)") to give you full controll over container"
    kill "$(cat $PID_FILE)"
    kill "$(lsof -i:8004 -t)"
    rm $PID_FILE
fi

cd /workspace
# Check if modules are present
if [ -z "$(ls -A $NODE_MODULES)" ]; then
   npm config set user 0
   npm i
fi